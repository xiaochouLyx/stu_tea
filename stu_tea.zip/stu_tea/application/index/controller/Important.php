<?php
namespace app\index\controller;

Use think\Controller;

/**
 * 
 */
class Important extends Controller
{
	
	public function _initialize()
	{
		$num=session('stu_num');
		if(!isset($num))
		{
			$this->error("请先登录！");
		}
	}

}
?>