<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\Student as Stu;
Use app\index\model\Group as Gro;
Use app\index\model\Chat as Cha;//使用各种数据库模型

/**
 * 
 */
class Studentchat extends Important//控制器类
{
	
	public function seek()//查看聊天列表
	{
		$stu=new Stu;
		$gro=new Gro;
		$num=session("stu_num");
		$result=$stu->alias('a')->join('group b',"a.stu_por=b.stu_por and a.stu_class=b.stu_class")->where("a.stu_num",$num)->select();//从数据库拉取聊天列表信息
		return $result;//返回聊天列表信息
	}

	public function index()//主页面对应方法，和聊天页面无关可以无视
	{
		
		// $student=Stu::where("stu_num",session("stu_num"))->find();
		// $name=$student->stu_name;
		$result=self::seek();
		$this->assign("name",session("stu_name"));
		$this->assign("group",$result);
		return $this->fetch();//渲染index页面
	}

	public function chat()
	{
		$result=self::seek();		//调用获取聊天群信息的方法
		$groupnum=input("groupnum");
		if (!empty($groupnum)) {
			$groupname=Gro::where("gro_num",$groupnum)->find();
			$url=url('index/Studentchat/tochat');
			$url=$url."?groupnum=".$groupnum;
			$this->assign("url",$url);
			$this->assign("name",session("stu_name"));
			$this->assign("group",$result);
			$this->assign("groupname",$groupname);
			$this->assign("groupnum",$groupnum);
			return $this->fetch();//渲染聊天页面
		}else{
			$this->redirect("index/Studentchat/index");//跳转到主页面
		}
	}

	public function tochat()//聊天页面对应方法，主要是这个方法和前端交互
	{
		$cha=new Cha;
		// $student=Stu::where("stu_num",session("stu_num"))->find();
		// $name=$student->stu_name;
		$groupnum=input("groupnum");//获取参数groupnum（即当前用户正在聊天的群号）并将其赋值给变量groupnum
		if (!empty($groupnum)) {//如果groupnum这个变量不为空，进入if语句
			# code...
			# code...
			$groupname=Gro::where("gro_num",$groupnum)->find();//从数据库获取当前群的信息
			// if (request()->isAjax()) {//如果有接受到用ajax发送过来的数据，进入if语句
				$lasttime=session("lasttime");
				$text=input("value");
				//获取参数text（即当前用户聊天需要发送的信息）并将其赋值给变量text
				// echo $text."/";
				if (!empty($text)) {//如果text这个变量不为空，进入if语句
					# code...
					// echo 2;
					$cha->chat_text=$text;
					$cha->chat_class=1;
					$cha->chat_num=session("stu_num");
					$cha->chat_name=session("stu_name");
					$cha->gro_num=$groupnum;
					$cha->save();//将text中的内容写入数据库并保存
				}
				$re=Cha::where("gro_num",$groupnum)->where("chat_time",">",$lasttime)->order("chat_time")->field("chat_text,chat_name,chat_time")->select();//从数据库取聊天记录
				// var_dump($re);
				return json_encode($re);//返回聊天记录
				
			// }
		
		
		}
	}

	public function histchat()
	{
		$cha=new Cha;
		$groupnum=input("groupnum");
		if (!empty($groupnum)) {
			$re=Cha::where("gro_num",$groupnum)->order("chat_time")->field("chat_text,chat_name,chat_time")->select();
			return json_encode($re);//返回聊天记录

		}
	}
}
?>
