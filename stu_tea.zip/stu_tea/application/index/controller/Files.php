<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\File as File;
Use app\index\model\Folder as Folder;
Use app\index\model\Sonfolder as Sonfolder;

/**
 * 
 */
class Files extends Controller
{

	public function _initialize()
	{
		$num=session('stu_num');
		$num2=session("tea_num");
		if((!isset($num))&&(!isset($num2)))
		{
			$this->error("请先登录！");
		}
	}

	public function upload()
	{
		$path=input("path");
		$type=input("type");
		$gro_num=input("groder");
		$filess = request()->file("file");
		$place=strripos($_FILES["file"]["name"],".");
		$str=substr($_FILES["file"]["name"],0,$place);;
		$names=urlencode($str);		
		$info = $filess->move($path,$names,false);
		// echo $name."<br>";
		// echo $str[0];
		// echo $info->getExtension()."<br>";
		// echo $info->getSaveName()."<br>";
		// echo $info->getFilename()."<br>";
		$message=$info->getInfo();
		// echo $message["size"]."<br>";
		if ($info) {
			# code...
			$file=new File;
			$file->filename=$_FILES["file"]["name"];
			$file->type=$info->getExtension();
			$file->size=$message["size"];
			$file->path=$path."/".$info->getSaveName();
			$file->creattype=$type;
			if ($type==1) {
				# code...
				$file->creatnum=session("stu_num");
				$file->creatname=session("stu_name");
			}
			else if($type==2){
				$file->creatnum=session("tea_num");
				$file->creatname=session("tea_name");
			}
			$file->gro_num=$gro_num;
			$file->save();
			$name=$file->fileId;
			$folder=new Sonfolder;
			$fileId=Folder::where("folderpath",$path)->find();
			$fileId=$fileId->folderId;
			$folder->folderId=$fileId;
			$folder->fileId=$name;
			$folder->save();
			$bol=$folder->folderId;
			if ($name&&$bol) {
				# code...
				$url1=url("index/Seekfile/seek");
				$path=urlencode($path);
				$url=$url1."?type=".$type."&path=".$path."&groder=".$gro_num;
				$this->success("上传成功！",$url);
			}
			else{
				$this->error("上传失败");
			}
			
			
		}
		else{
			$error="上传失败，失败原因：".$filess->getError();
			$this->error($error);
		}

	}

	public function newfolder()
	{
		$fatherpath=input("path");
		$type=input("type");
		$gro_num=input("groder");
		$foldername=input("foldername");
		$truename=urlencode($foldername);
		if ($type==1) {
			# code...
			$this->error("对不起您没有权限");
		}
		else if($type==2)
		{
			if (empty($foldername)) {
				# code...
				$this->error("请输入不为空的内容");
			}
			
			$path=$fatherpath."/".$truename;
			$existfolder=Folder::where("folderpath",$path)->find();
			$existfile=File::where("path",$path)->find();
			if ((!$existfolder)&&(!$existfile)) {
				# code...
				$folder=new Folder;
				$folder->foldername=$foldername;
				$folder->folderpath=$path;
				$folder->gro_num=$gro_num;
				$folder->save();
				$bol=$folder->folderId;
				$id=Folder::where("folderpath",$fatherpath)->find();
				$id=$id->folderId;
				$sonfolder=new Sonfolder;
				$sonfolder->folderId=$id;
				$sonfolder->sonsId=$bol;
				$sonfolder->save();
				$bol1=$sonfolder->folderId;
				$bol2=mkdir($path);
				if ($bol&&$bol1&&$bol2) {
					# code...
					$fatherpath=urlencode($fatherpath);
					$url1=url("index/Seekfile/seek");
					$url=$url1."?type=".$type."&path=".$fatherpath."&groder=".$gro_num;
					$this->success("创建成功！",$url);
				}
				else{
				$this->error("创建失败！");
				}
			}
			else{
				$this->error("已存在该文件夹或文件！");
			}
			
			
		}
		else{
			$this->error("出错啦！");
		}
	}

	public function delectfile()
	{
		$type=input("get.type");
		$filename=input("get.filename");
		$path=input("get.path");
		$groder=input("get.groder");
		$fatherpath=$path;
		$truename=urlencode($filename);

		if(strcmp($filename,"..")==0)
		{
			$patharr=explode("/",$path);
			array_pop($patharr);
			$path=implode("/", $patharr);
		}
		else
			$path=$path."/".$truename;

		if ($type==1) {
			# code...
			if (is_file($path)) {
				# code...
				$file=File::where("path",$path)->find();
				$id=$file->fileId;
				if ($file->creattype==1) {
					# code...
					$creatnum=$file->creatnum;
					$num=session("stu_num");
					if ($creatnum==$num) {
						# code...
						$bol=File::where("path",$path)->delete();
						$bol1=Sonfolder::where("fileId",$id)->delete();
						$bol2=unlink($path);
						if ($bol&&$bol1&&$bol2) {
							# code...
							$fatherpath=urlencode($fatherpath);
							$url1=url("index/Seekfile/seek");
							$url=$url1."?type=".$type."&path=".$fatherpath."&groder=".$groder;
							$this->success("删除成功！",$url);
						}
						else{
							$this->error("删除失败！");
						}
					}
					else{
						$this->error("对不起您没有权限！");
					}
				}
				else{
					$this->error("对不起您没有权限！");
				}

			}
			else{
				$this->error("对不起您没有权限！");
			}

		}
		else if($type==2)
		{
			if (is_file($path)) {
				# code...
				$file=File::where("path",$path)->find();
				$id=$file->fileId;
				$bol=File::where("path",$path)->delete();
				$bol1=Sonfolder::where("fileId",$id)->delete();
				$bol2=unlink($path);
				if ($bol&&$bol1&&$bol2) {
							# code...
					$fatherpath=urlencode($fatherpath);
					$url1=url("index/Seekfile/seek");
					$url=$url1."?type=".$type."&path=".$fatherpath."&groder=".$groder;
					$this->success("删除成功！",$url);
				}
				else{
					$this->error("删除失败！");
				}
			}
			else{
				$folder=Folder::where("folderpath",$path)->find();
				$id=$folder->folderId;
				$bol=Sonfolder::where("folderId",$id)->find();
				if (!$bol) {
					# code...
					$bol=Folder::where("folderpath",$path)->delete();
					$bol2=Sonfolder::where("sonsId",$id)->delete();
					$bol1=rmdir($path);
					if ($bol&&$bol1&&$bol2) {
						# code...
						$fatherpath=urlencode($fatherpath);
						$url1=url("index/Seekfile/seek");
						$url=$url1."?type=".$type."&path=".$fatherpath."&groder=".$groder;
						$this->success("删除成功！",$url);
					}
					else{
						$this->error("删除失败！");
					}
				}
				else{
					$this->error("该文件夹不为空不能删除！");
				}
			}
		}
		else{
			$this->error("出错啦");
		}
	}
	
}

?>