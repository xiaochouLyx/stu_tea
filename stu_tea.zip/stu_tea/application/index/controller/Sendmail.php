<?php

namespace app\index\controller;

Use PHPMailer\SendEmail;
Use app\index\model\Student as Stu;
Use app\index\model\Teacher as Tea;
Use app\index\model\Admin as Adm;
Use think\Controller;
/**
 * 
 */
class Sendmail extends Controller
{
	
	public function send()
	{

			# code...
		$result=SendEmail::SendEmail("hello！","php!","1596564207@qq.com");
		if ($result) {
			# code...
			return "success";
		}
		else
		{
			return "error";
		}
	}

	public function took($email,$num)
	{
		$took1=time();
		$took2=$took1.$email.$num;
		$took=md5($took2);
		return $took;
	}

	public function sendmails($email,$num,$type)
	{
		$took=self::took($email,$num);
		$tooktime=strtotime("+10minute");
		session('tooktime',$tooktime);
		// session("took",$took);
		if ($type==1) {
			# code...
			$student=Stu::get($num);
		}
		else if ($type==2) {
			# code...
			$student=Tea::get($num);
		}
		else if ($type==3) {
			# code...
			$student=Adm::get($num);
		}
		else{
			$this->error("出错啦！");
		}
		$student->took=$took;
		$student->save();
		$url="http://localhost/stu_tea/public/index/Sendmail/veract.html?took=".$took."&type=".$type;
		$messge="您好！请在10分钟内登陆下面的地址激活您的账户【如果不是本人操作请忽略该邮件】<br>".$url."&nbsp;(如果无法点击该URL链接地址，请将它复制并粘帖到“您申请激活功能的浏览器”的地址输入框，然后单击回车即可。)";
		$result=SendEmail::SendEmail("激活您的账户",$messge,$email);
		if ($result) {
			# code...
			$this->success("成功发送激活邮件，请注意查收","index/Index/index");
		}
		else
		{
			$this->error("发送激活邮件失败");
		}
	}

	public function veract($took,$type)
	{
		$tooktime=session('tooktime');
		// $took=session("took");
		$now=strtotime("now");
		if ($tooktime>$now) {
			# code...
			if ($type==1) {
			# code...
				$student=Stu::scope("Status0")->where("took",$took)->find();
			}
			else if ($type==2) {
				# code...
				$student=Tea::scope("Status0")->where("took",$took)->find();
			}
			else if ($type==3) {
				# code...
				$student=Adm::scope("Status0")->where("took",$took)->find();
			}
			else{
				$this->error("出错啦！");
			}
			if ($student) {
				# code...
				$student->status=1;
				$student->save();
				session('tooktime', null);
				$this->success("激活成功！请前去登陆","index/Index/index");
			}
			else
			{
				$this->error("激活失败！请重新激活！");
			}
			
		}
		else{
			session('tooktime', null);
			$this->error("激活有效期已过，请重新激活");
		}
	}

}

?>