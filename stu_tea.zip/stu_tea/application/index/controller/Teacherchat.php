<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\Teacher as Tea;
Use app\index\model\Group as Gro;
Use app\index\model\Chat as Cha;

/**
 * 
 */
class Teacherchat extends ImportantTeacher
{
	
	public function seek()
	{
		$tea=new Tea;
	 	$gro=new Gro;
	 	$num=session("tea_num");
	 	$name=session("tea_name");
		$result=Gro::where("tea_num",$num)->select();
		return $result;
	}

	public function index()
	{
		$tea=new Tea;
	 	$gro=new Gro;
	 	$num=session("tea_num");
	 	$name=session("tea_name");
		$result=Gro::where("tea_num",$num)->select();
		// $teacher=Tea::where("tea_num",$num)->find();
		// $name=$teacher->tea_name;
		$this->assign("name",$name);
		$this->assign("group",$result);
		return $this->fetch();
	}

	public function chat()
	{
		$result=self::seek();		//调用获取聊天群信息的方法
		$groupnum=input("groupnum");
		if (!empty($groupnum)) {
			$groupname=Gro::where("gro_num",$groupnum)->find();
			$url=url('index/Teacherchat/tochat');
			$url=$url."?groupnum=".$groupnum;
			$this->assign("url",$url);
			$this->assign("name",session("tea_name"));
			$this->assign("group",$result);
			$this->assign("groupname",$groupname);
			$this->assign("groupnum",$groupnum);
			return $this->fetch();//渲染聊天页面
		}else{
			$this->redirect("index/Teacherchat/index");//跳转到主页面
		}
	}

	public function tochat()
	{
		$cha=new Cha;
		// $teacher=Tea::where("tea_num",session("tea_num"))->find();
		// $name=$teacher->tea_name;
		$groupnum=input("groupnum");
		if (!empty($groupnum)) {
			# code...
			$groupname=Gro::where("gro_num",$groupnum)->find();
			# code...
			$lasttime=session("tea_lasttime");
			$text=input("value");
			if (!empty($text)) {
				# code...
				$cha->chat_text=$text;
				$cha->chat_class=2;
				$cha->chat_num=session("tea_num");
				$cha->chat_name=session("tea_name");
				$cha->gro_num=$groupnum;
				$cha->save();
			}
			$re=Cha::where("gro_num",$groupnum)->where("chat_time",">",$lasttime)->order("chat_time")->field("chat_text,chat_name,chat_time")->select();
			return json_encode($re);
		}
		
		
	}

	public function histchat()
	{
		$cha=new Cha;
		$groupnum=input("groupnum");
		if (!empty($groupnum)) {
			$re=Cha::where("gro_num",$groupnum)->order("chat_time")->field("chat_text,chat_name,chat_time")->select();
			return json_encode($re);//返回聊天记录

		}
	}
}
?>
