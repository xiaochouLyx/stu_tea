<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\File as File;
Use app\index\model\Folder as Folder;
Use app\index\model\Sonfolder as Sonfolder;
Use app\index\model\Group as Gro;
/**
 * 
 */
class Seekfile extends Controller
{
	public function _initialize()
	{
		$num=session('stu_num');
		$num2=session("tea_num");
		if((!isset($num))&&(!isset($num2)))
		{
			$this->error("请先登录！");
		}
	}


	public function down($path)
	{
		$file_name=basename($path);
		$file_name=urldecode($file_name);
		$fp=fopen($path,"r");
		$file_size=filesize($path);
		Header("Content-type: application/octet-stream"); 
		Header("Accept-Ranges: bytes"); 
		Header("Accept-Length:".$file_size); 
		Header("Content-Disposition: attachment; filename=".$file_name); 
		ob_clean(); 
		flush();
		readfile($path);
		fclose($fp);
	}

	public function seek()
	{
		$type=input("type");
		$filename=input("filename");
		$path=input("path");
		$groder=input("groder");//获取参数
		$truename=urlencode($filename);
		$fatherpath=$path;
		$path1="./upload/".$groder;
		if ((!$path)) {
			$path=$path1;
		}
		else if(strcmp($filename,"..")==0)
		{
			$patharr=explode("/",$path);
			array_pop($patharr);
			$path=implode("/", $patharr);
		}
		else if ((!$filename)) {
			# code...
			$path=$path;
		}
		else
			$path=$path."/".$truename;//获取当前路径
		if (is_dir($path)) {//如果是目录
			# code...

			$dh=opendir($path);
			if (!$dh) {
				# code...
				$this->error("出错啦!");
			}
			$file_name=readdir($dh);
			if (strcmp($path, $path1)==0) {
				$file_name=readdir($dh);
			}
			$file_name=readdir($dh);
			$i=0;$array=array();
			while ($file_name!=FALSE) {
				# code...
				$file_name=urldecode($file_name);
				$array[$i]=$file_name;
				$i++;
				$file_name=readdir($dh);
			}
			$groupname=Gro::where("gro_num",$groder)->find();
			// $url=url('index/Files/upload',['groder'=>$groder,'type'=>$type,'path'=>$path]);
			// return $url;
			$url1=url("index/Files/upload");
			$url2=url("index/Files/newfolder");
			$path=urlencode($path);
			$newurl=$url2."?groder=".$groder."&type=".$type."&path=".$path;
			$url=$url1."?groder=".$groder."&type=".$type."&path=".$path;
			$this->assign("url",$url);
			$this->assign("newurl",$newurl);
			$this->assign("groupname",$groupname);
			$this->assign("filename",$array);
			$this->assign("path",$path);
			$this->assign("type",$type);
			$this->assign("groder",$groder);
			return $this->fetch();
		}
		else{//如果是文件

			$place=strripos($filename,".");
			$conplace=0-$place+1;
			$str=substr($filename,0,$place);
			$suf=substr(strrchr($filename, '.'), 0);
			$names=urlencode($str).$suf;
			$path=$fatherpath."/".$names;
			self::down($path);

		}
		
	}

	public function test()
	{
		$place=strripos($_FILES["file"]["name"],".");
		$str=substr($_FILES["file"]["name"],0,$place);;
		$names=urlencode($str);	
		return $this->fetch();
	}
}

?>