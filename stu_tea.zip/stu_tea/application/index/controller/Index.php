<?php
namespace app\index\controller;

Use think\Controller;

class Index extends Controller
{
    public function index()
    {
        return $this->fetch();
    }
    public function teacher()
    {
        return $this->fetch();
    }
    public function admin()
    {
    	return $this->fetch();
    }
}
?>
