<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\Student as Stu;
Use app\index\model\Teacher as Tea;
Use app\index\model\Admin as Adm;



class Login extends Controller
{
	
	public function loginStudent()
	{
		$num=input("post.num");
		$password=input("post.password");
		$captcha=input('post.captcha');
		$password=md5($password);
		if (empty($num)||empty($password)||empty($captcha)) {
			# code...
			$this->error("输入不能为空！");
		}
		if (captcha_check($captcha)) {
			# code...
			$result=Stu::scope("Status1")->where(function($query)use($num,$password){$query->where("stu_num",$num)->where("stu_password",$password);})->whereOr(function($query)use($num,$password){$query->where("stu_email",$num)->where("stu_password",$password);})->find();
			if ($result) {
				# code...
				$stu_num=$result->stu_num;
				$stu_name=$result->stu_name;
				session("stu_name",$stu_name);
				session("stu_num",$stu_num);
				$lasttime=$result->logintime;
				session("lasttime",$lasttime);
				$time=strtotime("now");
				$time=date('Y-m-d H:i:s',$time);
				$result->logintime=$time;
				$result->save();
				$url=url('index/Studentchat/index');
				$this->success("登陆成功！",$url);
			}
			else
			{
				$result1=Stu::scope("Status0")->where(function($query)use($num,$password){$query->where("stu_num",$num)->where("stu_password",$password);})->whereOr(function($query)use($num,$password){$query->where("stu_email",$num)->where("stu_password",$password);})->find();
				if ($result1) {
					# code...
					$num=$result1->stu_num;
					$email=$result1->stu_email;
					$url1="email=".$email."&num=".$num."&type=1";
					$url=url('index/Sendmail/sendmails',$url1);
					$this->error("您的用户未激活，正在前去激活",$url);
				}
				else{
					$this->error("您输入的账号名或密码错误！");
				}
			}
		}
		else{
			$this->error("您输入的验证码错误！");
		}
		
	}

	public function loginTeacher()
	{
		$num=input("post.num");
		$password=input("post.password");
		$captcha=input('post.captcha');
		$password=md5($password);
		if (empty($num)||empty($password)||empty($captcha)) {
			# code...
			$this->error("输入不能为空！");
		}
		if (captcha_check($captcha)) {
			# code...
			$result=Tea::scope("Status1")->where(function($query)use($num,$password){$query->where("tea_num",$num)->where("tea_password",$password);})->whereOr(function($query)use($num,$password){$query->where("tea_email",$num)->where("tea_password",$password);})->find();
			if ($result) {
				# code...
				$tea_num=$result->tea_num;
				$tea_name=$result->tea_name;
				session("tea_name",$tea_name);
				session("tea_num",$tea_num);
				$lasttime=$result->logintime;
				session("tea_lasttime",$lasttime);
				$time=strtotime("now");
				$time=date('Y-m-d H:i:s',$time);
				$result->logintime=$time;
				$result->save();
				$url=url('index/Teacherchat/index');
				$this->success("登陆成功！",$url);
			}
			else
			{
				$result1=Tea::scope("Status0")->where(function($query)use($num,$password){$query->where("tea_num",$num)->where("tea_password",$password);})->whereOr(function($query)use($num,$password){$query->where("tea_email",$num)->where("tea_password",$password);})->find();
				if ($result1) {
					# code...
					$num=$result1->tea_num;
					$email=$result1->tea_email;
					$url1="email=".$email."&num=".$num."&type=2";
					$url=url('index/Sendmail/sendmails',$url1);
					$this->error("您的用户未激活，正在前去激活",$url);
				}
				else{
					$this->error("您输入的账号名或密码错误！");
				}
			}
		}
		else{
			$this->error("您输入的验证码错误！");
		}
		
	}

	public function loginAdmin()
	{
		$num=input("post.num");
		$password=input("post.password");
		$captcha=input('post.captcha');
		$password=md5($password);
		if (empty($num)||empty($password)||empty($captcha)) {
			# code...
			$this->error("输入不能为空！");
		}
		if (captcha_check($captcha)) {
			# code...
			$result=Adm::scope("Status")->where(function($query)use($num,$password){$query->where("adm_num",$num)->where("adm_password",$password);})->whereOr(function($query)use($num,$password){$query->where("adm_email",$num)->where("adm_password",$password);})->find();
			if ($result) {
				# code...
				$adm_num=$result->adm_num;
				session("adm_num",$adm_num);
				$url=url('admin/AdminCenter/seek');
				$this->success("登陆成功！",$url);
			}
			else
			{
				$result1=Adm::scope("Status0")->where(function($query)use($num,$password){$query->where("adm_num",$num)->where("adm_password",$password);})->whereOr(function($query)use($num,$password){$query->where("adm_email",$num)->where("adm_password",$password);})->find();
				if ($result1) {
					# code...
					$num=$result1->adm_num;
					$email=$result1->adm_email;
					$url1="email=".$email."&num=".$num."&type=3";
					$url=url('index/Sendmail/sendmails',$url1);
					$this->error("您的用户未激活，正在前去激活",$url);
				}
				else{
					$this->error("您输入的账号名或密码错误！");
				}
			}
		}
		else{
			$this->error("您输入的验证码错误！");
		}
		
	}
}

?>