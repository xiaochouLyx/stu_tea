<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\Student as Stu;
Use app\index\model\Teacher as Tea;
Use app\index\model\Admin as Adm;

class Regist extends Controller
{
	
	public function regist()
    {
        return $this->fetch();
    }
    public function fetchteacher()
    {
        return $this->fetch();
    }
    public function fetchadmin()
    {
        return $this->fetch();
    }

    public function registStudent()
    {
    	$student=new Stu;
    	$num=input('post.num');
    	$name=input('post.name');
    	$por=input('post.por');
    	$class=input('post.class');
    	$email=input('post.email');
    	$password=input('post.password');
    	$enpassword=input('post.enpassword');
    	$captcha=input('post.captcha');
    	if (empty($num)||empty($name)||empty($por)||empty($class)||empty($email)||empty($password)||empty($enpassword)||empty($captcha)) {
    		# code...
    		$this->error('输入不能为空！');
    	}
    	if (captcha_check($captcha)) {
    		# code...
    		if (preg_match("/^[0-9]{8}$/",$num)) {
    			# code...
    			if (preg_match("/^[0-9]{4}$/",$class)) {
    				# code...
    				if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/",$email)) {
    					# code...
    					if (preg_match("/^[0-9a-zA-Z_]*$/",$password)) {
    						# code...
    						if ($password==$enpassword) {
    							$result=Stu::get($num);
    							if (!$result) {
    								# code...
                                    $result=Stu::where("stu_email",$email)->find();
                                    if (!$result) {
                                        # code...
                                        $student->stu_num=$num;
                                        $student->stu_name=$name;
                                        $student->stu_por=$por;
                                        $student->stu_class=$class;
                                        $student->stu_email=$email;
                                        $student->stu_password=md5($password);
                                        $student->save();
                                        $url1="email=".$email."&num=".$num."&type=1";
                                        $url=url('index/Sendmail/sendmails',$url1);
                                        $this->success("正在前往发送激活邮件",$url);
                                    }
                                    else{
                                        $this->error("该邮箱已被注册请前去登陆!");
                                    }
    								
    							}
    							else{
    								$this->error("已存在该用户请前去登陆!");
    							}
	    						
    						}
    						else{
    							$this->error("确认密码和密码不符！");
    						}
    						
    					}
    					else{
    						$this->error("密码只能包含字母数字和下划线！");
    					}
    				}
    				else{
    					$this->error("请输入正确格式的邮箱地址！");
    				}
    			}
    			else{
    				$this->error("请输入正确格式的班级(例：1801)");
    			}

    		}
    		else{
    			$this->error("请输入8位纯数字学号！");
    		}
    	}
    	else{
    		$this->error("验证码不正确！");
    	}
    }

    public function registTeacher()
    {
        $student=new Tea;
        $num=input('post.num');
        $name=input('post.name');
        $email=input('post.email');
        $password=input('post.password');
        $enpassword=input('post.enpassword');
        $captcha=input('post.captcha');
        if (empty($num)||empty($name)||empty($email)||empty($password)||empty($enpassword)||empty($captcha)) {
            # code...
            $this->error('输入不能为空！');
        }
        if (captcha_check($captcha)) {
            # code...
            if (preg_match("/^[0-9]{8}$/",$num)) {

                 if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/",$email)) {
                        # code...
                        if (preg_match("/^[0-9a-zA-Z_]*$/",$password)) {
                            # code...
                            if ($password==$enpassword) {
                                $result=Tea::get($num);
                                if (!$result) {
                                    # code...
                                    $result=Tea::where("tea_email",$email)->find();
                                    if (!$result) {
                                        # code...
                                        $student->tea_num=$num;
                                        $student->tea_name=$name;
                                        $student->tea_email=$email;
                                        $student->tea_password=md5($password);
                                        $student->save();
                                        $url1="email=".$email."&num=".$num."&type=2";
                                        $url=url('index/Sendmail/sendmails',$url1);
                                        $this->success("正在前往发送激活邮件",$url);
                                    }
                                    else{
                                        $this->error("该邮箱已被注册请前去登陆!");
                                    }
                                    
                                }
                                else{
                                    $this->error("已存在该用户请前去登陆!");
                                }
                                
                            }
                            else{
                                $this->error("确认密码和密码不符！");
                            }
                            
                        }
                        else{
                            $this->error("密码只能包含字母数字和下划线！");
                        }
                    }
                   else{
                      $this->error("请输入正确格式的邮箱地址！");
                }
            }
            else{
                $this->error("请输入8位纯数字教工号！");
            }
        }
        else{
            $this->error("验证码不正确！");
        }
    }

    public function registAdmin()
    {
        $student=new Adm;
        $name=input('post.name');
        $email=input('post.email');
        $password=input('post.password');
        $enpassword=input('post.enpassword');
        $captcha=input('post.captcha');
        if (empty($name)||empty($email)||empty($password)||empty($enpassword)||empty($captcha)) {
            # code...
            $this->error('输入不能为空！');
        }
        if (captcha_check($captcha)) {

             if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/",$email)) {
                        # code...
                        if (preg_match("/^[0-9a-zA-Z_]*$/",$password)) {
                            # code...
                            if ($password==$enpassword) {
                                    # code...
                                    $result=Adm::where("adm_email",$email)->find();
                                    if (!$result) {
                                        # code...
                                        $student->adm_name=$name;
                                        $student->adm_email=$email;
                                        $student->adm_password=md5($password);
                                        $student->save();
                                        $num=$student->adm_num;
                                        $url1="email=".$email."&num=".$num;
                                        $url=url('index/Regist/sendadmin',$url1);
                                        $this->success("注册成功！请前去激活",$url);
                                    }
                                    else{
                                        $this->error("该邮箱已被注册请前去登陆!");
                                    }
                                
                            }
                            else{
                                $this->error("确认密码和密码不符！");
                            }
                            
                        }
                        else{
                            $this->error("密码只能包含字母数字和下划线！");
                        }
                    }
                   else{
                      $this->error("请输入正确格式的邮箱地址！");
            }
        }
        else{
            $this->error("验证码不正确！");
        }
    }

    public function sendadmin($email,$num)
    {
        if (request()->isPost()) {
            # code...
            $url1="email=".$email."&num=".$num."&type=3";
            $url=url('index/Sendmail/sendmails',$url1);
            $this->success("正在前往发送激活邮件",$url);
        }
        else
        {
            $this->assign("num",$num);
            $this->assign("email",$email);
            return  $this->fetch();
        }
         
    }
}

?>