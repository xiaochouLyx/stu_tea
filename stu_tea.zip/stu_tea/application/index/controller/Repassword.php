<?php

namespace app\index\controller;

Use think\Controller;
Use app\index\model\Student as Stu;
Use app\index\model\Teacher as Tea;
Use app\index\model\Admin as Adm;
Use PHPMailer\SendEmail;

/**
 * 
 */
class Repassword extends Controller
{
	public function index()
	{
		 return $this->fetch();
	}


	public function took($email,$num)
	{
		$took1=time();
		$took2=$took1.$email.$num;
		$took=md5($took2);
		return $took;
	}

	public function sendemail()
	{
		$num=input("post.num");
		$type=input("post.type");
		$captcha=input('post.captcha');
		if (empty($num)||empty($captcha)||empty($type)) {
			# code...
			$this->error("输入不能为空！");
		}
		if (captcha_check($captcha)) {
			# code...
			if ($type==1) {
			# code...
				$result=Stu::get($num);
				$email=$result->stu_email;
			}
			else if ($type==2) {
				# code...
				$result=Tea::get($num);
				$email=$result->tea_email;
			}
			else if ($type==3) {
				# code...
				$result=Adm::get($num);
				$email=$result->adm_email;
			}
			else{
				$this->error("出错啦！");
			}
			if ($result) {
				# code...				
				$took=self::took($email,$num);
				$tooktime=strtotime("+15minute");
				session('tooktime',$tooktime);
				$result->took=$took;
				$result->save();
				$url="http://localhost/stu_tea/public/index/Repassword/repass.html?took=".$took."&type=".$type;
				$messge="您好！请在15分钟内登陆下面的地址并修改您的账户密码【如果不是本人操作请忽略该邮件】<br>".$url."&nbsp;(如果无法点击该URL链接地址，请将它复制并粘帖到“您申请修改密码功能的浏览器”的地址输入框，然后单击回车即可。)";
				$result1=SendEmail::SendEmail("修改您的账户密码",$messge,$email);
				if ($result1) {
					# code...
					$mes="成功向您的注册邮箱(".$email.")发送激修改密码邮件，请注意查收";
					$this->success($mes,"index/Index/index");
				}
				else
				{
					$this->error("发送修改密码邮件失败");
				}
			}
			else{
				$this->error("不存在该账号！");
			}
		}
		else{
			$this->error("验证码输入出错！");
		}
	}

	public function repass($took,$type)
	{

		$tooktime=session('tooktime');
		// $took=session("took");
		$now=strtotime("now");
		if ($tooktime>$now) {
			# code...
			if ($type==1) {
			# code...
				$student=Stu::where("took",$took)->find();
				$num=$student->stu_num;
			}
			else if ($type==2) {
				# code...
				$student=Tea::where("took",$took)->find();
				$num=$student->tea_num;
			}
			else if ($type==3) {
				# code...
				$student=Adm::where("took",$took)->find();
				$num=$student->adm_num;
			}
			else{
				$this->error("出错啦！");
			}
			if (!$student) {
				# code..
				$this->error("临时码错误！请重新操作");
			}
			if (request()->isPost()) {
				# code...
				$password=input("post.password");
				$enpassword=input("post.enpassword");
				$captcha=input('post.captcha');
				if (empty($password)||empty($enpassword)||empty($captcha)) {
					# code...
					$this->error("请输入不能为空！");
				}
				if (captcha_check($captcha)){
					if (preg_match("/^[0-9a-zA-Z_]*$/",$password))  {
						# code...
						if ($password==$enpassword)  {
							# code...
							$password=md5($password);
							if ($type==1) {
			# code...
								$student->stu_password=$password;
							}
							else if ($type==2) {
								# code...
								$student->tea_password=$password;
							}
							else if ($type==3) {
								# code...
								$student->adm_password=$password;
							}
							else{
								$this->error("出错啦！");
							}
							$student->save();
							session('tooktime', null);
							$this->success("修改成功！正在前往登录","index/Index/index");
						}
						else{
							$this->error("确认密码和密码不符！");
						}
						
					}
					else{
						$this->error("密码只能包含字母数字或下划线！");
					}
					
				}
				else{
					$this->error("验证码输入出错！");
				}
				
			}
			else{
				$this->assign("num",$num);
				$this->assign("type",$type);
				return $this->fetch();
			}		
			
		}
		else{
			session('tooktime', null);
			$this->error("邮件有效期已过，请返回重新操作");
		}
	}
}


?>