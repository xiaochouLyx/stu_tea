<?php
namespace app\index\controller;

Use think\Controller;

/**
 * 
 */
class ImportantTeacher extends Controller
{
	
	public function _initialize()
	{
		$num=session('tea_num');
		if(!isset($num))
		{
			$this->error("请先登录！");
		}
	}

}
?>