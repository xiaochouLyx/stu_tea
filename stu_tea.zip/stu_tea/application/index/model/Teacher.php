<?php

namespace app\index\model;
/**
 * 
 */
use think\Model;
class Teacher extends Model
{
	
	public function getstatusAttr($value)
	{
		$status=[-1=>'禁用',0=>'待激活',1=>'正常'];
		return $status[$value];
	}

	public function scopeStatus0($query)
	{
		$query->where("status","0");
	}

	public function scopeStatus1($query)
	{
		$query->where("status","1");
	}

}

?>