<?php

namespace app\index\model;
/**
 * 
 */
use think\Model;
class Chat extends Model
{


}


?>