<?php

namespace app\index\model;
/**
 * 
 */
use think\Model;
class Admin extends Model
{
	
	public function getstatusAttr($value)
	{
		$status=[-1=>'禁用',0=>'待激活',1=>'无权限',2=>'低级管理员',3=>'高级管理员'];
		return $status[$value];
	}

	public function getapplyAttr($value)
	{
		$status=[0=>'未申请',1=>'已申请'];
		return $status[$value];
	}

	public function scopeStatus0($query)
	{
		$query->where("status","0");
	}

	public function scopeStatus1($query)
	{
		$query->where("status","1");
	}

	public function scopeStatus2($query)
	{
		$query->where("status","2");
	}

	public function scopeStatus3($query)
	{
		$query->where("status","3");
	}

	public function scopeStatus($query)
	{
		$query->wherein("status","1,2,3");
	}

}

?>