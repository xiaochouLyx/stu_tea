<?php

namespace app\admin\controller;

Use think\Controller;
Use app\index\model\File as File;
Use app\index\model\Folder as Folder;
Use app\index\model\Sonfolder as Sonfolder;
Use app\index\model\Group as Gro;
Use app\index\model\Admin as Adm;
/**
 * 
 */
class MangeFile extends ImportantAdmin
{
	public function _initialize()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status==1) {
			# code...
			$this->error("您无管理员权限，请前去申请管理员权限！");
		}
	}


	public function down($path)
	{
		$file_name=basename($path);
		$file_name=urldecode($file_name);
		$fp=fopen($path,"r");
		$file_size=filesize($path);
		Header("Content-type: application/octet-stream"); 
		Header("Accept-Ranges: bytes"); 
		Header("Accept-Length:".$file_size); 
		Header("Content-Disposition: attachment; filename=".$file_name); 
		ob_clean(); 
		flush();
		readfile($path);
		fclose($fp);
	}

	public function seek()
	{
		$filename=input("filename");
		$path=input("path");
		$groder=input("groder");//获取参数
		$truename=urlencode($filename);
		$fatherpath=$path;
		$path1="./upload/".$groder;
		if ((!$path)) {
			$path=$path1;
		}
		else if(strcmp($filename,"..")==0)
		{
			$patharr=explode("/",$path);
			array_pop($patharr);
			$path=implode("/", $patharr);
		}
		else if ((!$filename)) {
			# code...
			$path=$path;
		}
		else
			$path=$path."/".$truename;//获取当前路径
		if (is_dir($path)) {//如果是目录
			# code...

			$dh=opendir($path);
			if (!$dh) {
				# code...
				$this->error("出错啦!");
			}
			$file_name=readdir($dh);
			if (strcmp($path, $path1)==0) {
				$file_name=readdir($dh);
			}
			$file_name=readdir($dh);
			$i=0;$array=array();
			while ($file_name!=FALSE) {
				# code...
				$file_name=urldecode($file_name);
				$array[$i]=$file_name;
				$i++;
				$file_name=readdir($dh);
			}
			$groupname=Gro::where("gro_num",$groder)->find();
			// $url=url('index/Files/upload',['groder'=>$groder,'type'=>$type,'path'=>$path]);
			// return $url;
			// $url1=url("index/Files/upload");
			// $url2=url("index/Files/newfolder");
			$path=urlencode($path);
			// $newurl=$url2."?groder=".$groder."&type=".$type."&path=".$path;
			// $url=$url1."?groder=".$groder."&type=".$type."&path=".$path;
			// $this->assign("url",$url);
			// $this->assign("newurl",$newurl);
			$this->assign("groupname",$groupname);
			$this->assign("filename",$array);
			$this->assign("path",$path);
			// $this->assign("type",$type);
			$this->assign("groder",$groder);
			return $this->fetch();
		}
		else{//如果是文件

			$place=strripos($filename,".");
			$conplace=0-$place+1;
			$str=substr($filename,0,$place);
			$suf=substr(strrchr($filename, '.'), 0);
			$names=urlencode($str).$suf;
			$path=$fatherpath."/".$names;
			self::down($path);

		}

		
	}

	public function delectfile()
	{
		$filename=input("get.filename");
		$path=input("get.path");
		$groder=input("get.groder");
		$fatherpath=$path;
		$truename=urlencode($filename);

		if(strcmp($filename,"..")==0)
		{
			$patharr=explode("/",$path);
			array_pop($patharr);
			$path=implode("/", $patharr);
		}
		else
			$path=$path."/".$truename;

		if (is_file($path)) {
				# code...
			$file=File::where("path",$path)->find();
			$id=$file->fileId;
			$bol=File::where("path",$path)->delete();
			$bol1=Sonfolder::where("fileId",$id)->delete();
			$bol2=unlink($path);
			if ($bol&&$bol1&&$bol2) {
								# code...
				$fatherpath=urlencode($fatherpath);
				$url1=url("admin/MangeFile/seek");
				$url=$url1."?path=".$fatherpath."&groder=".$groder;
				$this->success("删除成功！",$url);
			}
			else{
				$this->error("删除失败！");
			}
		}
		else{
			$folder=Folder::where("folderpath",$path)->find();
			$id=$folder->folderId;
			$bol=Sonfolder::where("folderId",$id)->find();
			if (!$bol) {
				# code...
				$bol=Folder::where("folderpath",$path)->delete();
				$bol2=Sonfolder::where("sonsId",$id)->delete();
				$bol1=rmdir($path);
				if ($bol&&$bol1&&$bol2) {
					# code...
					$fatherpath=urlencode($fatherpath);
					$url1=url("admin/MangeFile/seek");
					$url=$url1."?path=".$fatherpath."&groder=".$groder;
					$this->success("删除成功！",$url);
				}
				else{
					$this->error("删除失败！");
				}
			}
			else{
				$this->error("该文件夹不为空不能删除！");
			}
		}
	}
	

}

?>