<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;
Use app\index\model\Student as Stu;
/**
 * 
 */
class ManageStudent extends ImportantAdmin
{
	public function _initialize()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status==1) {
			# code...
			$this->error("您无管理员权限，请前去申请管理员权限！");
		}
	}

	public function seek()
	{
		$student=Stu::paginate(20);
		$page =$student->render();
		$this->assign('page', $page);
		$this->assign("student",$student);
		return $this->fetch();
	}

	public function permissions()
	{
		$studentid=input("studentid");
		$student=Stu::get($studentid);
		$status=$student->getData('status');
		if ($status==-1) {
			# code...
			$student->status=0;
			$bol=$student->save();
			if ($bol) {
				# code...
				$this->success("启用成功！");
			}
			else{
				$this->error("启用失败！");
			}

		}
		else{

			$student->status=-1;
			$bol=$student->save();
			if ($bol) {
				# code...
				$this->success("禁用成功！");
			}
			else{
				$this->error("禁用失败！");
			}

		}

	}

}
?>