<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;
Use PHPMailer\SendEmail;
/**
 * 
 */
class AdminCenter extends ImportantAdmin
{

	public function seek()
	{
		$adminid=session("adm_num");
		$admin=Adm::where("adm_num",$adminid)->find();
		$this->assign("admin",$admin);
		return $this->fetch();
	}

	public function Rename()
	{
		if (request()->isPost()) {
			# code...
			$adminid=session("adm_num");
			$adm_name=input("admname");
			$admin=Adm::get($adminid);
			if (empty($adm_name)) {
				# code...
				$this->error("输入不能为空！");
			}
			$admin->adm_name=$adm_name;
			$bol=$admin->save();
			if ($bol) {
				# code...
				$url=url("admin/AdminCenter/seek");
				$this->success("修改成功！",$url);
			}
			else{
				$this->error("修改失败！");
			}
		}
		else{
			return $this->fetch();
		}
	}
		

	public function took($email,$num)
	{
		$took1=time();
		$took2=$took1.$email.$num;
		$took=md5($took2);
		return $took;
	}

	public function sendReemail()
	{
		if (request()->isPost()) {
			# code...
			$adminid=session("adm_num");
			$email=input("email");
			$captcha=input('post.captcha');
			$admin=Adm::get($adminid);
			if (empty($email)||empty($captcha)) {
				# code...
				$this->error("验证码和邮箱不能为空！");
			}
			if (captcha_check($captcha)) {
				if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/",$email)) {
					# code...
					$took=self::took($email,$adminid);
					$tooktime=strtotime("+15minute");
					session('tooktime',$tooktime);
					$admin->took=$took;
					$admin->save();
					$url="http://localhost/stu_tea/public/admin/admin_center/Reemail.html?took=".$took."&email=".$email;
					$messge="您好！请在15分钟内登陆下面的地址确认修改您的邮箱【如果不是本人操作请忽略该邮件】<br>".$url."&nbsp;(如果无法点击该URL链接地址，请将它复制并粘帖到“您申请修改密码功能的浏览器”的地址输入框，然后单击回车即可。)";
					$result1=SendEmail::SendEmail("修改您的账户邮箱",$messge,$email);
					if ($result1) {
						# code...
						$mes="成功向您的邮箱(".$email.")发送激修邮箱邮件，请注意查收";
						$this->success($mes);
					}
					else
					{
						$this->error("发送修改邮箱邮件失败");
					}

				}
				else{
					$this->error("请输入正确的邮箱格式！");
				}
			}
			else{
				$this->error("验证码错误！");
			}
		}
		else{
			return $this->fetch();
		}
		
	}

	public function Reemail()
	{
		$took=input("took");
		$email=input("email");
		$tooktime=session('tooktime');
		$adminid=session("adm_num");
		$now=strtotime("now");
		if ($tooktime>$now) {
			$admin=Adm::where("took",$took)->find();
			if ($admin) {
				# code...
				$admin->adm_email=$email;
				$bol=$admin->save();
				$url=url("admin/AdminCenter/seek");
				if ($bol) {
					# code...
					$this->success("修改成功！",$url);
				}
				else{
					$this->error("修改失败！");
				}
				
			}
			else{
				$this->error("临时码错误！");
			}
			

		}
		else{
			session('tooktime', null);
			$this->error("邮件有效期已过，请返回重新操作");
		}
	}

	public function Repassword()
	{
		if (request()->isPost()) {
			# code...
			$adminid=session("adm_num");
			$password=input("post.password");
			$repassword=input("post.repassword");
			$enpassword=input("post.enpassword");
			$captcha=input('post.captcha');
			if (empty($password)||empty($captcha)||empty($repassword)) {
				# code...
				$this->error("输入不能为空！");
			}
			if (captcha_check($captcha)) {
				$password=md5($password);
				$admin=Adm::where("adm_num",$adminid)->where("adm_password",$password)->find();
				if ($admin) {
					# code...
					if (preg_match("/^[0-9a-zA-Z_]*$/",$repassword)) {
						# code...
						if ($repassword==$enpassword) {
						# code...
							$admin->adm_password=md5($repassword);
							$bol=$admin->save();
							if ($bol) {
								# code...
								$this->success("修改成功！");
							}
							else{
								$this->error("修改失败！");
							}

						}
						else{
							$this->error("确认密码和修改密码不同！");
						}
					}
					else{
						$this->error("密码只能包含字母数字和下划线！");
					}
					
				}
				else{
					$this->error("密码输入错误！");
				}
			}
			else{
				$this->error("验证码错误！");
			}
		}
		else{
			return $this->fetch();
		}
		
	}

	public function apply()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status<3) {
			# code...
			$admin->apply=1;
			$bol=$admin->save();
			if ($bol) {
				# code...
				$this->success("申请成功！等待高级管理员处理");

			}
			else{
				$this->error("申请失败");
			}
		}
		else{
			$this->error("您已是最高级管理员！");
		}
	}
}


?>