<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;
Use app\admin\model\Course as Course;
Use app\index\model\Group as Gro;
Use app\index\model\Folder as Folder;
Use app\index\model\Sonfolder as Sonfolder;
Use app\index\model\File as File;
Use app\index\model\Chat as Cha;
/**
 * 
 */
class ManageGroup extends ImportantAdmin
{

	public function _initialize()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status==1) {
			# code...
			$this->error("您无管理员权限，请前去申请管理员权限！");
		}
	}
	
	public function seek()
	{
		$group=Gro::paginate(20);
		$page =$group->render();
		$this->assign('page', $page);
		$this->assign("group",$group);
		return $this->fetch();
	}

	public function add()
	{
		if (request()->isPost()) {
			# code...
			$cournum=input("cournum");
			$captcha=input("post.captcha");
			if (empty($cournum)||empty($captcha)) {
				# code...
				$this->error("输入不能为空！");
			}
			if (captcha_check($captcha)) {
				$course=Course::where("cour_num",$cournum)->find();
				if ($course) {
					$gro=Gro::where("cour_num",$cournum)->find();
					if (!$gro) {
						# code...
						$courname=$course->cour_name;
						$teanum=$course->tea_num;
						$stupor=$course->stu_por;
						$stuclass=$course->stu_class;
						if (empty($courname)||empty($teanum)||empty($stupor)||empty($stuclass)) {
							# code...
							$this->error("该门课程的信息不完全不能创建班级群组！");

						}
						$group=new Gro;
						$group->stu_por=$stupor;
						$group->stu_class=$stuclass;
						$group->cour_name=$courname;
						$group->cour_num=$cournum;
						$group->tea_num=$teanum;
						$bol=$group->save();
						if ($bol) {
							# code...
							$groupid=$group->gro_num;
							$folder=new Folder;
							$folder->foldername=$groupid;
							$path="./upload/".$groupid;
							$folder->folderpath=$path;
							$folder->gro_num=$groupid;
							$bol1=$folder->save();
							$bol2=mkdir($path);
						}
						
						if ($bol&&$bol1&&$bol2) {
							# code...
							$this->success("添加成功！");
						}
						else{
							$this->error("添加失败");
						}

					}else{
						$this->error("已存在该群组！");
					}
					# code...
					
				}
				else{
					$this->error("对不起不存在该门课程");
				}
			}
			else{
				$this->error("您输入的验证码不正确！");
			}
		}else{
			return $this->fetch();
		}

	}

	public function deletedire($path)
	{
		$dh=opendir($path);
		if (!$dh) {
			# code...
			$this->error("打开文件夹失败");
		}
		$file_name=readdir($dh);
		$file_name=readdir($dh);
		$file_name=readdir($dh);
		while ($file_name!=FALSE) {
			# code...
			$sonpath=$path."/".$file_name;
			if (is_dir($sonpath)) {
				
					self::deletedire($sonpath);
			}
			else{

				$bol=unlink($sonpath);
				if (!$bol) {
					# code...
					$this->error("删除失败1");
				}
			}
			$file_name=readdir($dh);
		}
		closedir($dh);
		$folder=Folder::where("folderpath",$path)->find();
		$folderId=$folder->folderId;
		Sonfolder::where("folderId",$folderId)->delete();
		$bol=rmdir($path);
		if (!$bol) {
			# code...
			$this->error("删除失败3");
		}
	}

	public function delect()
	{
		$gronum=input("gronum");
		
		$path="./upload/".$gronum;
		// $path="^".$path;
		// array_map('unlink', glob($path));
		self::deletedire($path);
		$bol2=Folder::where("gro_num",$gronum)->delete();
		$bol=Gro::where("gro_num",$gronum)->delete();
		File::where("gro_num",$gronum)->delete();
		Cha::where("gro_num",$gronum)->delete();
		if ($bol&&$bol2) {
			# code...
			$this->success("删除成功！");
		}
		else{
			$this->error("删除失败！4");
		}
	}
}

?>