<?php
namespace app\admin\controller;

Use think\Controller;

/**
 * 
 */
class ImportantAdmin extends Controller
{
	
	public function _initialize()
	{
		$num=session('adm_num');
		if(!isset($num))
		{
			$this->error("请先登录！");
		}
	}

}
?>