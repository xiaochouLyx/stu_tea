<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;

/**
 * 
 */
class ManageAdmin extends ImportantAdmin
{
	public function _initialize()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status<3) {
			# code...
			$this->error("您无权限，请前去申请高级管理员权限！");
		}
	}
	
	public function seek()
	{
		$admin=Adm::paginate(6);
		$page =$admin->render();
		$this->assign("admin",$admin);
		$this->assign('page', $page);
		return $this->fetch();
	}

	public function conlevel()
	{
		$adminid=session("adm_num");
		$admin=Adm::where("adm_num",$adminid)->find();
		$status=$admin->getData('status');
		return $status;
	}

	public function seekapply()
	{
		$admin=Adm::where("apply",1)->paginate(6);
		$page =$admin->render();
		$this->assign('page', $page);
		$this->assign("admin",$admin);
		return $this->fetch();
	}

	public function dealapply()
	{
		$status=self::conlevel();
		$adminid=input("adminid");
		$admin=Adm::where("adm_num",$adminid)->find();
		$appstatus=$admin->getData('status');
		if ($status==3) {
			# code...
			$admin=Adm::get($adminid);
			$newstatus=$appstatus+1;
			$admin->status=$newstatus;
			$admin->apply=0;
			$bol=$admin->save();
			if ($bol) {
				# code...
				$this->success("处理成功！");
			}
			else{
				$this->error("处理失败");
			}
		}
		else{
			$this->error("出错啦！");
		}
	}

	public function disable()
	{
		$status=self::conlevel();
		$adminid=input("adminid");
		$admin=Adm::where("adm_num",$adminid)->find();
		$disstatus=$admin->getData('status');
		if ($disstatus==-1) {
			# code...
			$admin=Adm::get($adminid);
			$admin->status=0;
			$bol=$admin->save();
			if ($bol) {
				# code...
				$this->success("启用成功！");
			}
			else{
				$this->error("启用失败！");
			}
		}
		else{
			if ($status==3) {
				# code...
				if ($disstatus>=$status) {
					# code...
					$this->error("对方与你同为高级管理员，您无权限！");
				}
				else{
					$admin=Adm::where("adm_num",$adminid)->find();
					$admin->status=-1;
					$bol=$admin->save();
					if ($bol) {
				# code...
						$this->success("禁用成功！");
					}
					else{
						$this->error("禁用失败！");
					}
				}

			}
			else{
				$this->error("出错啦！");
			}
		}
		

	}

}

?>