<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;

class Index extends ImportantAdmin
{
    public function index()
    {
    	$num=session("adm_num")
    	$admin=Adm::where("adm_num",$num)->find();
    	$status=$admin->status;
    	if ($status==1) {
    		# code...
    		$this->redirect("admin/Index/nothing")
    	}
    	else if($status==2) {
    		# code...
    		return $this->fetch();

    	} else if ($status==3) {
    		# code...
    		$this->redirect("admin/Index/senior");
    	}
    	else{

    		$this->error("出错啦！");
    	}
    	
        
    }

    public function senior()
    {
    	return $this->fetch();
    }

    public function nothing()
    {
        return $this->fetch();
    }
}
?>