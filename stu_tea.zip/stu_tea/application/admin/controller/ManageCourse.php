<?php
namespace app\admin\controller;

Use think\Controller;
Use app\index\model\Admin as Adm;
Use app\admin\model\Course as Course;
Use app\index\model\Group as Gro;
Use app\index\model\Teacher as Tea;
Use app\index\model\Folder as Folder;
Use app\index\model\Sonfolder as Sonfolder;
Use app\index\model\File as File;
Use app\index\model\Chat as Cha;
/**
 * 
 */
class ManageCourse extends ImportantAdmin
{

	public function _initialize()
	{
		$adminid=session("adm_num");
		$admin=Adm::get($adminid);
		$status=$admin->getData('status');
		if ($status==1) {
			# code...
			$this->error("您无管理员权限，请前去申请管理员权限！");
		}
	}

	public function seek()
	{
		$course=Course::paginate(20);
		$page =$course->render();
		$this->assign('page', $page);
		$this->assign("course",$course);
		return $this->fetch();
	}
	
	public function add()
	{
		if (request()->isPost()) {
			# code...
			$cournum=input("post.cournum");
			$courname=input("post.courname");
			$teanum=input("post.teanum");
			$stupor=input("post.stupor");
			$stuclass=input("post.stuclass");
			$captcha=input("post.captcha");
			if (empty($cournum)||empty($courname)) {
				# code...
				$this->error("课程编号和课程名称不能为空！");
			}
			if (captcha_check($captcha)) {
				# code...
				if(preg_match("/^[0-9]*$/",$cournum)){
					if (!empty($teanum)) {
						# code...
						$bol=Tea::get($teanum);
						if (!$bol) {
							# code...
							$this->error("不存在该教工!");
						}		
					}
					$course=new Course;
					$course->cour_num=$cournum;
					$course->cour_name=$courname;
					$course->tea_num=$teanum;
					$course->stu_por=$stupor;
					$course->stu_class=$stuclass;
					$bol=$course->save();
					if ($bol) {
						# code...
						$this->success("新增成功！");
					}
					else{
						$this->error("新增失败！");
					}
				}
				else{
					$this->error("课程编号只能为纯数字！");
				}

			}
			else{
				$this->error("您输入的验证码不正确！");
			}

		}
		else{
			return $this->fetch();
		}
	}

	public function deletedire($path)
	{
		$dh=opendir($path);
		if (!$dh) {
			# code...
			$this->error("打开文件夹失败");
		}
		$file_name=readdir($dh);
		$file_name=readdir($dh);
		$file_name=readdir($dh);
		while ($file_name!=FALSE) {
			# code...
			$sonpath=$path."/".$file_name;
			if (is_dir($sonpath)) {
				
					self::deletedire($sonpath);
			}
			else{

				$bol=unlink($sonpath);
				if (!$bol) {
					# code...
					$this->error("删除失败");
				}
			}
			$file_name=readdir($dh);
		}
		closedir($dh);
		$folder=Folder::where("folderpath",$path)->find();
		$folderId=$folder->folderId;
		Sonfolder::where("folderId",$folderId)->delete();
		$bol=rmdir($path);
		if (!$bol) {
					# code...
			$this->error("删除失败");
		}
	}

	public function delete()
	{
		$cournum=input("cournum");
		$bol=Course::where("cour_num",$cournum)->delete();
		$group=Gro::where("cour_num",$cournum)->find();
		$bol1=1;
		$bol2=1;
		if ($group) {
			# code...
			$groupid=$group->gro_num;
			$path="./upload/".$groupid;
			self::deletedire($path);
			$bol1=Gro::where("cour_num",$cournum)->delete();
			$bol2=Folder::where("gro_num",$groupid)->delete();
			File::where("gro_num",$groupid)->delete();
			Cha::where("gro_num",$groupid)->delete();
			// $path="^".$path;
			// array_map('unlink', glob($path));
			
		}
		if ($bol&&$bol1&&$bol2) {
			# code...
			$this->success("删除成功！");
		}
		else{
			$this->error("删除失败！");
		}

	}

	public function change()
	{
		$cournum=input("cournum");
		$course=Course::where("cour_num",$cournum)->find();
		if (request()->isPost()) {
			$courname=input("post.courname");
			$teanum=input("post.teanum");
			$stupor=input("post.stupor");
			$stuclass=input("post.stuclass");
			$captcha=input("post.captcha");
			if (captcha_check($captcha)) {
				if (empty($courname)) {
				# code...
				$this->error("课程名称不能为空！");
				}
				$gro=Gro::where("cour_num",$cournum)->find();
				if ($gro) {
					# code...
					if (empty($teanum)||empty($stupor)||empty($stuclass)) {
						# code...
						$this->error("该课程已绑定群组，其教工号专业班级不能为空");
					}
				}
				if (!empty($teanum)) {
					# code...
					$bol=Tea::get($teanum);
					if (!$bol) {
						# code...
						$this->error("不存在该教工!");
					}		
				}
				$re=Course::where("cour_num",$cournum)->find();
				$re->cour_name=$courname;
				$re->tea_num=$teanum;
				$re->stu_por=$stupor;
				$re->stu_class=$stuclass;
				$bol=$re->save();
					
				$bol2=1;
				if ($gro) {
					# code...
					$gro->stu_por=$stupor;
					$gro->stu_class=$stuclass;
					$gro->cour_name=$courname;
					$gro->tea_num=$teanum;
					$bol2=$gro->save();
				}
				if ($bol&&$bol2) {
					# code...
					$this->success("修改成功！");
				}
				else{
					$this->error("修改失败");
				}	
				
			}
			else{
				$this->error("验证码错误！");
			}
		}
		else{
			$this->assign("course",$course);
			return $this->fetch();
		}
		
	}

	
}