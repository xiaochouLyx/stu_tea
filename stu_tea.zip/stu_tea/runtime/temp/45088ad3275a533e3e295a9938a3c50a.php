<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\manage_group\seek.html";i:1584524544;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理员群组</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/admin.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>">个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>" >管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>" class="active">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>" >管理管理员</a></li>
            
     </ul>
     <div class="reside">
        <div class="table">
            <div class="tille">群组信息管理</div>
             <div class="massage">
                 <table>   
                    <thead>
                        <tr>
                            <th>群号</th>
                            <th>专业</th>
                            <th>班级</th>
                            <th>课程名称</th>
                            <th>课程编号</th>
                            <th>任课教工号</th>
                            <th colspan="2"><a href="<?php echo url('admin/ManageGroup/add'); ?>"><button>添加群组</button></a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(is_array($group) || $group instanceof \think\Collection || $group instanceof \think\Paginator): $i = 0; $__LIST__ = $group;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo $vo['gro_num']; ?></td>
                            <td><?php echo $vo['stu_por']; ?></td>
                            <td><?php echo $vo['stu_class']; ?></td>
                            <td><?php echo $vo['cour_name']; ?></td>
                            <td><?php echo $vo['cour_num']; ?></td>
                            <td><?php echo $vo['tea_num']; ?></td>
                            <td><a href="<?php echo url('admin/ManageGroup/delect',['gronum'=>$vo['gro_num']]); ?>"><button>删除</button></a></td>
                            <td><a href="<?php echo url('admin/MangeFile/seek',['groder'=>$vo['gro_num']]); ?>"><button>文件</button></a></td>  
                         </tr>   
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table> 
             </div>
             <div class="page">
                <?php echo $page; ?>
             </div>
        </div>
    </div>
</body>
</html>