<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"C:\php\wamp64\www\stu_tea\public/../application/index\view\index\teacher.html";i:1581865578;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/login.css">
    </head>
    <body>
        <div class="user_login">
            <div class="title">老师登录</div>
        <form  action="<?php echo url('index/Login/loginTeacher'); ?>" method="POST">
            <input type="text" placeholder="教工号/邮箱" class="numbers" name="num">
            <input type="password" placeholder="密码" name="password">
            <div class="captcha">
            	<div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
            	<div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
            </div>
            <div class="register"><a href="<?php echo url('index/Regist/fetchteacher'); ?>">免费注册</a></div>
            <div class="forget_password"><a href="<?php echo url('/index/Repassword/index'); ?>">忘记密码？</a></div>
            <div class="register"><a href="<?php echo url('index/Index/index'); ?>">学生登录</a></div>
            <div class="forget_password"><a href="<?php echo url('/index/Index/admin'); ?>">管理员登录</a></div>
            <input class="" type="submit" value="登录">
        </form>
        </div>
    </body>
</html>