<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\manage_group\add.html";i:1584518451;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>添加群组</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/addgroup.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>" >个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>" class="active">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>">管理管理员</a></li>
            
     </ul>
     <div class="reside">
         <div class="massage">
             <div class="title">添加群组</div>
                <form  action="" method="POST">
                    <input type="text" name="cournum" placeholder="课程编号">
                    <div class="captcha">
                        <div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
                        <div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
                    </div>
                    <input class="" type="submit" value="增加">
                </form>
         </div>
    </div>
</body>
</html>