<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\php\wamp64\www\stu_tea\public/../application/index\view\regist\sendadmin.html";i:1581840597;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>发送邮件</title>
	<meta charset="utf-8">
	 <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/sendadmin.css"> 
</head>
<body>
	<div class="send_admin">
    <div class="title">注册成功！<br>您的管理员账户账号为<?php echo $num; ?>,<br>请向您的绑定邮箱<?php echo $email; ?>发送激活邮件</div>
    <form action="" method="POST">
      <input type="hidden" name="hidden" value="1"> 
      <input type="submit" value="发送邮件">
    </form>
	</div>
</body>
</html>