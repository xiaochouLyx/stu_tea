<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/index\view\studentchat\index.html";i:1584451335;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <title>聊天主页</title>
    <meta charset="utf-8">
    <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/studentindex.css">
</head>

<body>
    <div class="capital">
            <div class="login"><a href="<?php echo url('index/Index/index'); ?>">注销</a></div>
            <div class="register">学生<?php echo $name; ?></div>
            <div class="person"><a href="1">个人中心</a></div>
        </div>
     <div class="images">
         <img src="/stu_tea/public/static/front/images/1.jpg">
    </div>
    <div class="classes">

        <?php if(is_array($group) || $group instanceof \think\Collection || $group instanceof \think\Paginator): $i = 0; $__LIST__ = $group;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <div>
            <a href="<?php echo url('index/Studentchat/chat',['groupnum'=>$vo['gro_num']]); ?>"><?php echo $vo['stu_por']; ?><?php echo $vo['stu_class']; ?><?php echo $vo['cour_name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
   
        
</body>

</html>