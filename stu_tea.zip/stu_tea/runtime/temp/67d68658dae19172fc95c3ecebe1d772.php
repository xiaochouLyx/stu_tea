<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/index\view\regist\fetchadmin.html";i:1581839140;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/registadmin.css"> 
    </head>
    <body>
        <div class="user_register">
            <div class="title">管理员注册</div>
            <form  action="<?php echo url('index/Regist/registAdmin'); ?>" method="POST">
	            <input type="text" name="name" placeholder="姓名">
	            <input type="email" placeholder="邮箱" name="email">
	            <input type="password" placeholder="密码" name="password">
	            <input type="password" placeholder="确认密码" name="enpassword">
	            <div class="captcha">
	            	<div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
	            	<div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
            	</div>
            <button>注册</a></button>
        	</form>
        </div>
    </body>
</html>