<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\admin_center\rename.html";i:1582878999;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理员个人中心</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/rename.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>" class="active">个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>">管理管理员</a></li>
            
     </ul>
     <div class="reside">
         <div class="massage">
             <div class="title">修改个人姓名</div>
                <form  action="<?php echo url(''); ?>" method="POST">
                    <input type="text" placeholder="姓名" class="numbers" name="admname">
                    <input class="" type="submit" value="修改">
                </form>
         </div>
    </div>
</body>
</html>