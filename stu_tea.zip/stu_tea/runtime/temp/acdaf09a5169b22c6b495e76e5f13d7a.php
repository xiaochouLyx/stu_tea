<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:78:"C:\php\wamp64\www\stu_tea\public/../application/index\view\login\activate.html";i:1580540603;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form action="" method="POST">
		学号：<input type="text" name="num">
		邮箱：<input type="text" name="email"><br>
		<input type="submit" value="激活">
	</form>
	<a href="<?php echo url('index/Regist/Regist'); ?>">点击此处注册</a><br>
	<a href="<?php echo url('/index/Index/index'); ?>">点击此处登陆</a><br>
</body>
</html>