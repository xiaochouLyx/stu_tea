<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:77:"C:\php\wamp64\www\stu_tea\public/../application/index\view\seekfile\test.html";i:1581335001;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
		<form action="<?php echo url('index/Files/upload'); ?>" enctype="multipart/form-data" method="post">
			<input type="file" name="file" /> <br> 
			<input type="submit" value="上传" /> 
		</form>
</body>
</html>