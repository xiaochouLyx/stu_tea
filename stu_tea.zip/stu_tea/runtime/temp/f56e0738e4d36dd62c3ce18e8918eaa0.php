<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:84:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\manage_course\change.html";i:1584542714;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>修改课程信息</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/addcourse.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>" >个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>" class="active">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>">管理管理员</a></li>
            
     </ul>
     <div class="reside">
         <div class="massage">
             <div class="title">修改课程信息</div>
                <form  action="" method="POST">
                    <input type="text" name="courname" placeholder="课程名称" value="<?php echo $course['cour_name']; ?>">
                    <input type="text" name="teanum" placeholder="任课教师教工号" value="<?php echo $course['tea_num']; ?>">
                    <input type="text" name="stupor" placeholder="开设专业" value="<?php echo $course['stu_por']; ?>">
                    <input type="text" name="stuclass" placeholder="开设班级" value="<?php echo $course['stu_class']; ?>">
                    <div class="captcha">
                        <div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
                        <div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
                    </div>
                    <input class="" type="submit" value="修改">
                </form>
         </div>
    </div>
</body>
</html>