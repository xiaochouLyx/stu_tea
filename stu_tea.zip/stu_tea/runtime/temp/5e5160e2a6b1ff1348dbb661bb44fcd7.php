<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:79:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\mange_file\seek.html";i:1584521191;}*/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/stu_tea/public/static/front/css/file.css">
    <title>文件信息</title>
</head>

<body>
    <div id="content">
        <ul class="classify">
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">返回管理群组</a></li>
            <li id="all">全部文件</li>
            <li id="pic">图片</li>
            <li id="doc">文档</li>
            <li id="video">视频</li>
            <li id="music">音乐</li>
            <li id="other">其他</li>
        </ul>
        <div class="file-title">
            <div class="grouptitle">群：<?php echo $groupname['stu_por']; ?><?php echo $groupname['stu_class']; ?><?php echo $groupname['cour_name']; ?>
            </div>
            
        </div>
        <div class="file">
            <!-- <div id="fileAll"></div> -->
            <div id="filePic">图片</div>
            <div id="fileDoc">文档</div>
            <div id="fileVideo">视频</div>
            <div id="fileMusic">音乐</div>
            <div id="fileOther">其他</div>
        </div>
        <div class="seek">
        	<?php if(is_array($filename) || $filename instanceof \think\Collection || $filename instanceof \think\Paginator): $i = 0; $__LIST__ = $filename;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;
        		$url1=url('admin/MangeFile/seek');
        		$seekurl=$url1."?groder=".$groder."&path=".$path."&filename=".$vo;
        		$url2=url('admin/MangeFile/delectfile');
        		$delecturl=$url2."?groder=".$groder."&path=".$path."&filename=".$vo;
        	?>
     		<div class="seekfile">
     			<a href="<?php echo $seekurl; ?>"><img src="/stu_tea/public/static/front/images/文件夹.png"></a>
     			<div><?php echo $vo; ?></div>
     			<div ><a href="<?php echo $delecturl; ?>"><button class="button" >删除</button></a></div>
     		</div>
     		 <?php endforeach; endif; else: echo "" ;endif; ?>
        </div>
    </div>

</body>

</html>