<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:87:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\admin_center\repassword.html";i:1582879945;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理员个人中心</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/repassword.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>" class="active">个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>">管理管理员</a></li>
            
     </ul>
     <div class="reside">
         <div class="massage">
             <div class="title">修改个人密码</div>
                <form  action="" method="POST">
                    <input type="password" placeholder="旧密码" class="numbers" name="password">
                    <input type="password" placeholder="新密码" class="numbers" name="repassword">
                     <input type="password" placeholder="确认密码" class="numbers" name="enpassword">
                    <div class="captcha">
                        <div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
                        <div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
                    </div>
                    <input class="" type="submit" value="修改">
                </form>
         </div>
    </div>
</body>
</html>