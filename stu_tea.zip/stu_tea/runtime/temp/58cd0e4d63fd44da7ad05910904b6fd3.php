<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\manage_admin\seek.html";i:1583916847;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理管理员</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/admin.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>">个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>" class="active">管理管理员</a></li>
            
     </ul>
     <div class="reside">
        <div class="table">
            <div class="tille">管理员信息管理</div>
             <div class="massage">
                 <table>   
                    <thead>
                        <tr>
                            <th>管理员编号</th>
                            <th>管理员姓名</th>
                            <th>管理员邮箱</th>
                            <th>管理员密码</th>
                            <th>管理员状态</th>
                            <th colspan="2"><a href="<?php echo url('admin/ManageAdmin/seekapply'); ?>"><button>查看申请</button></a></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(is_array($admin) || $admin instanceof \think\Collection || $admin instanceof \think\Paginator): $i = 0; $__LIST__ = $admin;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <tr>
                            <td><?php echo $vo['adm_num']; ?></td>
                            <td><?php echo $vo['adm_name']; ?></td>
                            <td><?php echo $vo['adm_email']; ?></td>
                            <td>******</td>
                            <td><?php echo $vo['status']; ?></td>
                           <?php switch($vo['status']): case "禁用": ?><td><a href="<?php echo url('admin/ManageAdmin/disable',['adminid'=>$vo['adm_num']]); ?>"><button>启用</button></a></td><?php break; default: ?><td><a href="<?php echo url('admin/ManageAdmin/disable',['adminid'=>$vo['adm_num']]); ?>"><button>禁用</button></a></td>  
                            <?php endswitch; ?>
                         </tr>   
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </tbody>
                </table> 
             </div>
             <div class="page">
                <?php echo $page; ?>
             </div>
        </div>
    </div>
</body>
</html>