<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/admin\view\admin_center\seek.html";i:1582878912;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<title>管理员个人中心</title>
	<meta charset="UTF-8">
	<link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/admin/css/center.css">
</head>
<body>
    
	<ul class="navigation">
           <div class="top">管理员</div>
            <li><a href="<?php echo url('admin/AdminCenter/seek'); ?>" class="active">个人中心</a></li>
            <li><a href="<?php echo url('admin/ManageCourse/seek'); ?>">管理课程</a></li>
            <li><a href="<?php echo url('admin/ManageGroup/seek'); ?>">管理群组</a></li>
            <li><a href="<?php echo url('admin/ManageStudent/seek'); ?>">管理学生</a></li>
            <li><a href="<?php echo url('admin/ManageTeacher/seek'); ?>">管理老师</a></li>
            <li><a href="<?php echo url('admin/ManageAdmin/seek'); ?>">管理管理员</a></li>
            
     </ul>
     <div class="reside">
         <div class="massage">
             <div class="image">
                 <img src="/stu_tea/public/static/front/images/manage.jpg">
             </div>
             <div class="information">
                 <ul>
                     <li>管理员编号：<?php echo $admin['adm_num']; ?></li>
                     <li>管理员姓名：<?php echo $admin['adm_name']; ?><!-- &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp; --><button><a href="<?php echo url('admin/AdminCenter/Rename'); ?>">修改</a></button></li>
                     <li>管理员邮箱：<?php echo $admin['adm_email']; ?><button><a href="<?php echo url('admin/AdminCenter/sendReemail'); ?>">修改</a></button></li>
                     <li>管理员密码：********<!-- &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp; --><button><a href="<?php echo url('admin/AdminCenter/Repassword'); ?>">修改</a></button></li>
                     <li>管理员状态：<?php echo $admin['status']; ?></li>
                     <li>申请状态：<?php echo $admin['apply']; ?><!-- &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp; --><button><a href="<?php echo url('admin/AdminCenter/apply'); ?>">申请</a></button></li>
                 </ul>
             </div>
         </div>
    </div>
</body>
</html>