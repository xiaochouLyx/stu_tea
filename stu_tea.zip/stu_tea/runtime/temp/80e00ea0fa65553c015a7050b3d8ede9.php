<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"C:\php\wamp64\www\stu_tea\public/../application/index\view\repassword\repass.html";i:1581865469;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
       <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/repassword.css">
    </head>
    <body>
        <div class="change_password">
            <div class="title">修改您账户(<?php echo $num; ?>)的密码</div>
            <form action="" method="POST">
                <input type="password" placeholder="密码" name="password">
                <input type="password" placeholder="确认密码" name="enpassword">
                <div class="captcha">
                    <div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
                    <div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
                 </div>
                <button>修改</button>  
            </form>
            
        </div>
    </body>
</html>