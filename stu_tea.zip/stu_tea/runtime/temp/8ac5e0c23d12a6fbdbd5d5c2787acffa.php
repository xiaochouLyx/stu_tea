<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\php\wamp64\www\stu_tea\public/../application/index\view\teacherchat\chat.html";i:1584541811;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <title>聊天</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="/stu_tea/public/static/front/css/chatFile.css">
         <link rel="stylesheet" href="/stu_tea/public/static/front/css/studentChat.css">
    </head>
    <body>
        <div class="capital">
            <div class="index">群：<?php echo $groupname['stu_por']; ?><?php echo $groupname['stu_class']; ?><?php echo $groupname['cour_name']; ?></div>
           <div class="login"><a href="<?php echo url('index/Index/index'); ?>">注销</a></div>
            <div class="register">老师<?php echo $name; ?></div>
            <div class="person"><a href="1">个人中心</a></div>
        </div>
        <div class="classes">

        <?php if(is_array($group) || $group instanceof \think\Collection || $group instanceof \think\Paginator): $i = 0; $__LIST__ = $group;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <div>
            <a href="<?php echo url('index/Teacherchat/chat',['groupnum'=>$vo['gro_num']]); ?>"><?php echo $vo['stu_por']; ?><?php echo $vo['stu_class']; ?><?php echo $vo['cour_name']; ?></a>
        </div>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
        <div class="file">
            <a href="<?php echo url('index/Seekfile/seek',['groder'=>$groupnum,'type'=>2]); ?>"><span class="iconfont icon-wenjian" title="文件"></span></a>
        </div>
        <div class="value_content" id="content">
            
        </div>
        <div class="input_frame">
            <textarea id="value">

            </textarea>
            <button onclick="load()">发送</buttovaluen>
        </div>
         <script>
            window.onload = function reset() {
                    setTimeout(reset, 1000 * 2)
                    var time
                    var name
                    var text
                    var xmlhttp
                    if (window.XMLHttpRequest) {
                            xmlhttp = new XMLHttpRequest()
                        } else {
                            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
                    }
                    xmlhttp.onreadystatechange = function () {
                        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
                            var mid = ""
                            var value1 = JSON.parse(xmlhttp.responseText)
                            for(var pro in value1) {
                            time = value1[pro].chat_time
                            name = value1[pro].chat_name
                            text = value1[pro].chat_text
                            mid +=` <p>发送者：${name}  时间：${time}</p>
                            <p>消息内容： ${text}</p>`
                            }
                            document.getElementById("content").innerHTML = mid
                        }
                    }
                    xmlhttp.open("POST", '<?php echo $url; ?>', true)
                    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
                    xmlhttp.send("value=" + "")
                }
            function load() {
                    var xmlhttp
                    
                    var value=document.getElementById("value").value
                    if (window.XMLHttpRequest) {
                        xmlhttp = new XMLHttpRequest()
                    } else {
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
                    }
                    
                    // 空着的部分填写php文件的地址
                    xmlhttp.open("POST", '<?php echo $url; ?>', true)
                    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded")
                    xmlhttp.send("value=" + value)
                }
        </script>
    </body>
</html>