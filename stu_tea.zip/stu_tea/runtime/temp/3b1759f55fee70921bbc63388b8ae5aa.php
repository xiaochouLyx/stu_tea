<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"C:\php\wamp64\www\stu_tea\public/../application/index\view\repassword\index.html";i:1581866236;}*/ ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"> 
        <link rel="stylesheet"   type="text/css" href="/stu_tea/public/static/front/css/forgetPassword.css">
    </head>
    <body>
        <div class="forget_password">
            <div class="title">忘记密码</div>
            <form method="POST" action="<?php echo url('index/Repassword/sendemail'); ?>">
	            <input type="text" placeholder="学号/教工号/编号" class="numbers" name="num">
	            <div class="select">
	            	<select name="type">
		            	<option value="" >选择身份</option>
		            	<option value="1" >学生</option>
		            	<option value="2" >老师</option>
		            	<option value="3" >管理员</option>
	           	 </select>
	            </div>
	            <div class="captcha">
	            	<div class="input"><input  class="inputcaptcha" type="text" name="captcha" placeholder="验证码"></div>
	            	<div class="imgcaptcha"><img src="<?php echo captcha_src(); ?>" onclick="this.src='<?php echo captcha_src(); ?>?+Math.random();'" title="看不清楚?点击刷新验证码?"></div>
            	</div>
<!-- 	            <div class="get_code">获取验证码</div> -->
	            <input type="submit" value="修改密码">	
            </form>
            
        </div>
    </body>
</html>